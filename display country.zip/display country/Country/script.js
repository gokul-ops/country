let Container = document.createElement("div");
Container.className = "container";
document.body.appendChild(Container);


let fetchDataBtn = document.createElement("button");
fetchDataBtn.innerText   = "Fetch data";
fetchDataBtn.className = "fetchDataBtn";
Container.appendChild(fetchDataBtn);

const result = document.createElement("div");
result.className = "result";
Container.appendChild(result);



fetchDataBtn.addEventListener('click', async() => {
    try{
        const response = await fetch("https://api.openbrewerydb.org/breweries?page=1&per_page=50");
        const jsonData = await response.json();
        console.log(jsonData);

        
        for(let i = 0; i < jsonData.length; i++) {
            let brewData = document.createElement("div"); 
            brewData.innerHTML = `
            <div class = "card">
                <div class = "card-body">
                   Country: ${jsonData[i].country}<br><br>
                    </a>
            `
            result.appendChild(brewData);
            
        }
        
    }
    catch(error){
        result.innerHTML = error;
    }
    console.log("flags")
});



searchBtn.addEventListener("click", async() => {
    let searchTerm = document.querySelector(".searchInput").value;
    
   
    const response = await fetch("https://api.openbrewerydb.org/breweries?page=1&per_page=50");
    const jsonData = await response.json();
    

    
    let filtered_arr = [];
    
   
    for(let i = 0; i < jsonData.length; i++){
        if((jsonData[i].name.toLowerCase()).includes(searchTerm.toLowerCase())){
            filtered_arr.push(jsonData[i]);
        }
    }
    
    
    const emptyResult = document.querySelector(".result");
    emptyResult.innerHTML = "";
    

   
    for(let i = 0; i < filtered_arr.length; i++) {
        let brewData = document.createElement("div"); 
        brewData.innerHTML = `
        <div class = "card">
            <div class = "card-body">
               Country: ${filtered_arr[i].country}<br><br>
               </a>
        `
        result.appendChild(brewData);
        
    }
    
    
   
});
